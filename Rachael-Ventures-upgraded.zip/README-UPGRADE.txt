# Rachael Ventures upgraded website
Upload `index.html` to the root of the `Rachael-ventures` GitHub repository and replace the existing file.
The design is mobile-friendly and includes search, category filtering, WhatsApp enquiries, and a listing submission form.
Note: GitHub Pages alone is static. To make customer-submitted listings appear publicly for everyone and to accept online payments automatically, connect a hosted database/authentication and payment provider.
